package com.example.AsmGD1.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "checkouts")
public class Checkout {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto tăng giá trị ID
    private Integer id;

    @Column(nullable = false)
    private Integer userId;

    @Column(nullable = false)
    private BigDecimal totalPrice; // Tổng tiền

    @Column(nullable = false)
    private String status; // Pending, Completed, Cancelled

    @Column(nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now(); // Ngày tạo đơn hàng

    // Getters and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}

