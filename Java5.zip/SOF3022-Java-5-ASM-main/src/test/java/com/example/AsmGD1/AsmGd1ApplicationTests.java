package com.example.AsmGD1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsmGd1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
